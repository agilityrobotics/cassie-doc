% BATTERYMODULE Cassie battery module
%
%    Reference page in Doc Center
%       doc BatteryModule
%
%