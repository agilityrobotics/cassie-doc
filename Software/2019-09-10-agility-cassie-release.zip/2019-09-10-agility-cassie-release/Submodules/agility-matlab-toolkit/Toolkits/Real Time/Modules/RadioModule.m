% RADIOMODULE Radio module
%
%    Reference page in Doc Center
%       doc RadioModule
%
%