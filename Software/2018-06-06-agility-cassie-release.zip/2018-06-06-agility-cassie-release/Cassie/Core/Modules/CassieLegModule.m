% CASSIELEGMODULE Cassie leg module
%
%    Reference page in Doc Center
%       doc CassieLegModule
%
%