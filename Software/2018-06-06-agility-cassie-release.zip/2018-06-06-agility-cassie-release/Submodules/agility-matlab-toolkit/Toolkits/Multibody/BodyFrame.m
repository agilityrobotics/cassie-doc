% BODYFRAME Implements a inertial reference frame
% 
%  Syntax:
%    bodyFrame = BodyFrame('Name', parentFrame)
%
%    Reference page in Doc Center
%       doc BodyFrame
%
%