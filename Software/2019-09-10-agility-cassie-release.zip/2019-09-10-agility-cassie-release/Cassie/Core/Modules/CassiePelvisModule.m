% CASSIEPELIVSMODULE Cassie pelvis module
%
%    Reference page in Doc Center
%       doc CassiePelvisModule
%
%