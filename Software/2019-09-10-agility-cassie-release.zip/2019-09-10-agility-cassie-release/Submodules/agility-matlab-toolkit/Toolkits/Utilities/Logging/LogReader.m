% LOGREADER Reads log files in a variety of formats
% 
%  Syntax:
%    log = LogReader(logStruct)
%    log.load(filePath, logType)
%
%    Reference page in Doc Center
%       doc LogReader
%
%