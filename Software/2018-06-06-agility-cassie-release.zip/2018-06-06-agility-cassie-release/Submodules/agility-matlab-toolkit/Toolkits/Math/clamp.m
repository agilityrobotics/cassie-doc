% CLAMP Clamp value between two bounds
% 
%  Syntax:
%    b = clamp(a, limit_1, limit_2);
%