% LOGMODULE Log module
%
%    Reference page in Doc Center
%       doc LogModule
%
%