% DEBOUNCE Implements a debounce filter object
%
%    Reference page in Doc Center
%       doc Debounce
%
%