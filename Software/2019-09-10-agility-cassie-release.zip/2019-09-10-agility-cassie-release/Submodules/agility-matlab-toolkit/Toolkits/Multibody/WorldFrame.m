% WORLDFRAME Implements a world reference frame
% 
%  Syntax:
%    frame = WorldFrame
%
%    Reference page in Doc Center
%       doc WorldFrame
%
%