% JOINT Implements an abstract multi body tree joint object
% 
%  Syntax:
%    joint = Joint('Name', parentFrame)
%
%    Reference page in Doc Center
%       doc Joint
%
%