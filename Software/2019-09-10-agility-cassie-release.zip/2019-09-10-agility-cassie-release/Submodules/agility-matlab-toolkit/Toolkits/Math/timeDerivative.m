% TIMEDERIVATIVE Compute symbolic time derivative of a matrix
% 
%  Syntax:
%    [dAdt, dxdt] = timeDerivative(A, x)
%