% TARGETPCMODULE Target PC module
%
%    Reference page in Doc Center
%       doc TargetPcModule
%
%